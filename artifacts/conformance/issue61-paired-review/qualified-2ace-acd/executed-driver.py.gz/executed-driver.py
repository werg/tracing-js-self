"""Execute real Promise components while preserving the full-gate boundary."""
import argparse
from datetime import datetime, timezone
import importlib.metadata
import importlib.util
import json
from pathlib import Path
import platform
import re
import subprocess
import sys
from types import SimpleNamespace

parser = argparse.ArgumentParser()
for name in ("producer", "native", "policy", "out"):
    parser.add_argument("--" + name, type=Path, required=True)
for name in ("producer-revision", "native-revision"):
    parser.add_argument("--" + name, required=True)
args = parser.parse_args()
producer, native = args.producer.resolve(), args.native.resolve()
out, policy = args.out.resolve(), args.policy.resolve()
out.mkdir(parents=True, exist_ok=False)
spec = importlib.util.spec_from_file_location("gate", producer / "tools/verify-combined-v8-gate.py")
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
pair = gate.identity(producer, native, args.producer_revision, args.native_revision, policy)
environment = gate.read(producer / "profiles/release-environment.lock.json")
node = subprocess.check_output(["node", "--version"], text=True).strip().removeprefix("v")
gate.require(platform.python_version() == environment["python"], "Python differs from lock")
gate.require(node == environment["node"] == (producer / ".nvmrc").read_text().strip(), "Node differs from lock")
lock = producer / "tools/native-consumer/requirements.lock"
expected = dict(re.findall(r"^([A-Za-z0-9_.-]+)==([^\s\\]+)", lock.read_text(), re.M))
packages = {name: importlib.metadata.version(name) for name in expected}
gate.require(packages == expected, "Dependency versions differ from hashed lock")
for suffix in ("", ".resolution.json"):
    with (out / ("semantic-native-policy-v8.json" + suffix)).open("xb") as stream:
        stream.write(Path(str(policy) + suffix).read_bytes())
gate.retained_policy(out, policy)
(out / "executed-driver.py").write_bytes(Path(__file__).read_bytes())
receipt = {
    "schema": "issue61-local-promise-checks/1",
    "pair": pair,
    "startedAt": datetime.now(timezone.utc).isoformat(),
    "completeCombinedGate": "not-qualified",
    "kernelTimeNamespaceAvailable": Path("/proc/self/ns/time").is_symlink(),
    "strictAttestation": "separate unchanged full-gate attestation required",
    "runtime": {"node": node, "python": platform.python_version(), "packages": packages,
                "requirementsLockSha256": gate.sha(lock)},
    "payloads": gate.payload_parity(producer, native),
    "installed": gate.installed_consumer(producer, native, True),
}
if not receipt["kernelTimeNamespaceAvailable"]:
    receipt["strictAttestation"] = "blocked: /proc/self/ns/time is not exposed in this workspace"
gate.write(out / "installed-replay.json", receipt)
print(json.dumps({"installedSourceCases": len(receipt["installed"]["sourceReceipts"]),
                  "pair": pair, "completeCombinedGate": "not-qualified"}), flush=True)
env = gate.lane_environment(SimpleNamespace(producer=producer, native=native, out=out, native_policy=policy))
results = {}
for kind in ("native", "producer"):
    files = gate.SPEC["lanes"]["promise"][kind]
    xml = out / (kind + ".xml")
    if kind == "native":
        argv = [sys.executable, "-m", "pytest", "-q", *files,
                "--junitxml=" + str(xml), "--basetemp=" + str(out / "pytest")]
    else:
        argv = ["node", "--experimental-vm-modules", "--test", "--test-concurrency=1",
                "--test-timeout=600000", "--test-reporter=spec", "--test-reporter-destination=stdout",
                "--test-reporter=junit", "--test-reporter-destination=" + str(xml), *files]
    gate.command(argv, native if kind == "native" else producer, out / (kind + ".log"), env)
    results[kind] = gate.verify_junit(xml, kind, files)
packets = gate.verify_promise_packets(out)
gate.require(pair == gate.identity(producer, native, args.producer_revision, args.native_revision, policy),
             "Exact pair changed during execution")
gate.retained_policy(out, policy)
gate.write(out / "local-promise-result.json", {
    "schema": "issue61-local-promise-result/1", "pair": pair, "promiseTests": results,
    "sourcePopulations": packets, "installedReplaySha256": gate.sha(out / "installed-replay.json"),
    "finishedAt": datetime.now(timezone.utc).isoformat(),
    "completeCombinedGate": "not-qualified", "strictAttestation": receipt["strictAttestation"],
    "moduleAdmission": False, "trainingAdmission": False, "optimizerUpdates": 0,
})
print(json.dumps({"promiseTests": results, "completeCombinedGate": "not-qualified"}), flush=True)
