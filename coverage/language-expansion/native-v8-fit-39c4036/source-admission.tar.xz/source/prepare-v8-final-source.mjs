import {readFileSync,writeFileSync} from 'node:fs';
import {verifyRegionTrainingCase,admitRegionEvidence} from './v8-final-producer/src/semantic/compiler-v8.js';
import {loadNativeV8Settings,createNativeV8Consumer} from './v8-final-producer/src/corpus/native-admission-v8.mjs';
const base='/workspace/scratch/d11743e0247b',out=base+'/v8-model-final-source';
const policy=JSON.parse(readFileSync(base+'/v8-final-producer/contracts/semantic-native-policy-v8.json','utf8'));
policy.consumerRevision='39c4036564428e44cc89caf261f517d856482695';
writeFileSync(out+'/policy.json',JSON.stringify(policy,null,2)+'\n');
const settings=loadNativeV8Settings({megatoken:base+'/v8-final-native',tokenizer:base+'/tokenizer.json',
  python:base+'/native-venv/bin/python',policyFile:out+'/policy.json',temporaryDirectory:out+'/native'});
const nativeConsumer=createNativeV8Consumer(settings),rows=[];
for(const [id,args] of [['fit-increment',[6]],['heldout-increment',[8]]]){
  const fixture={id,family:'v8-model-increment',source:'"use strict";function run(x){return x+1;}',entry:'run',args,fixture:{calls:[]}};
  const result=await verifyRegionTrainingCase(fixture);
  if(!result.exported)throw new Error(result.reason);
  writeFileSync(out+'/'+id+'.source.json',JSON.stringify(result.exported)+'\n');
  const admitted=await admitRegionEvidence(result.exported,{nativePolicy:policy,nativeConsumer});
  writeFileSync(out+'/'+id+'.admitted.json',JSON.stringify(admitted.exported)+'\n');
  writeFileSync(out+'/'+id+'.native.json',JSON.stringify(admitted.native,null,2)+'\n');
  const row={id,args,sourceArtifact:id+'.source.json',admittedArtifact:id+'.admitted.json',nativeReceipt:id+'.native.json',
    generated:result.exported.public.timeline.filter(row=>row.mode==='generated').map(row=>row.fields.line),
    checks:admitted.native.checks};rows.push(row);console.log(JSON.stringify(row));
}
writeFileSync(out+'/cases.json',JSON.stringify(rows.map(row=>({id:row.id,artifactPath:row.sourceArtifact})),null,2)+'\n');
writeFileSync(out+'/manifest.json',JSON.stringify({schema:'semantic-v8-trained-smoke-input/1',producerRevision:'012c9fe49a082319bf98ac0c571596da925741a4',
  consumerRevision:policy.consumerRevision,policy,trainingCase:'fit-increment',holdoutCase:'heldout-increment',rows},null,2)+'\n');
