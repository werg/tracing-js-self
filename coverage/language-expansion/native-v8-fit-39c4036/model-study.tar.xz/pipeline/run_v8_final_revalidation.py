import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

BASE = Path('/workspace/scratch/d11743e0247b')
OUT = BASE / 'v8-final-model-revalidation'
SOURCE = BASE / 'v8-model-final-source'
RUN = BASE / 'v8-frozen-native-final-source'
PRODUCER = BASE / 'v8-final-producer'
CONSUMER = BASE / 'v8-final-native'
OUT.mkdir()
SOURCE.mkdir()
RUN.mkdir()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot(path):
    def git(*args):
        return subprocess.check_output(['git', '-C', str(path), *args], text=True).strip()
    return {'revision': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD:'),
            'status': git('status', '--porcelain', '--untracked-files=all')}


pins = {'producer': snapshot(PRODUCER), 'consumer': snapshot(CONSUMER)}
assert pins['producer']['revision'] == '012c9fe49a082319bf98ac0c571596da925741a4'
assert pins['consumer']['revision'] == '39c4036564428e44cc89caf261f517d856482695'
assert not any(p['status'] for p in pins.values())
model_hashes = {name: sha(BASE / 'v8-native-bounded-fit' / name / 'model.safetensors')
                for name in ['baseline', 'fitted']}
for name in ['model-identities.json', 'settings.json']:
    shutil.copyfile(BASE / 'v8-frozen-native-current-source' / name, RUN / name)
assert model_hashes == json.loads((RUN / 'model-identities.json').read_text())
env = dict(os.environ, PYTHONPATH=str(CONSUMER / 'src'), OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
receipt = {
    'schema': 'semantic-v8-final-model-revalidation/1',
    'startedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'pins': pins, 'modelIdentitiesBefore': model_hashes, 'additionalOptimizerSteps': 0,
    'scripts': {name: sha(BASE / name) for name in
                ['prepare-v8-final-source.mjs', 'run-v8-frozen-final-source.py']},
    'settings': json.loads((RUN / 'settings.json').read_text()),
    'commands': [],
}

for label, command in [
    ('source-admission', ['node', str(BASE / 'prepare-v8-final-source.mjs')]),
    ('frozen-model-study', [sys.executable, str(BASE / 'run-v8-frozen-final-source.py')]),
]:
    start = time.monotonic()
    log = OUT / (label + '.log')
    with log.open('w') as output:
        result = subprocess.run(command, cwd=BASE, env=env, stdout=output, stderr=subprocess.STDOUT)
    receipt['commands'].append({'name': label, 'command': command, 'exitCode': result.returncode,
                                'elapsedSeconds': time.monotonic() - start,
                                'log': log.name, 'logSha256': sha(log)})
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt['commands'][-1]), flush=True)
    if result.returncode:
        sys.exit(result.returncode)

receipt['finalPins'] = {'producer': snapshot(PRODUCER), 'consumer': snapshot(CONSUMER)}
receipt['modelIdentitiesAfter'] = {name: sha(BASE / 'v8-native-bounded-fit' / name / 'model.safetensors')
                                   for name in ['baseline', 'fitted']}
receipt['identityUnchanged'] = receipt['finalPins'] == pins and receipt['modelIdentitiesAfter'] == model_hashes
receipt['finishedUtc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt['reports'] = {}
for name in ['baseline', 'fitted']:
    path = RUN / (name + '-run/report.json')
    report = json.loads(path.read_text())
    receipt['reports'][name] = {'sha256': sha(path), 'summary': report['summary'],
                                'cleanup': report['cleanup']}
assert receipt['identityUnchanged']
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'identityUnchanged': True, 'reports': receipt['reports']}), flush=True)
