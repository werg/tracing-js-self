import json, os, pathlib, subprocess

root = pathlib.Path('/workspace/scratch/d11743e0247b')
out = root / 'v8-frozen-native-final-source'
producer = root / 'v8-final-producer'
consumer = root / 'v8-final-native'
tool = producer / 'tools/run-semantic-v8-experiment.mjs'
models = json.loads((out / 'model-identities.json').read_text())
env = dict(os.environ, PYTHONPATH=str(consumer / 'src'), OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
for label, checkpoint in models.items():
    study = out / (label + '-study')
    result = out / (label + '-run')
    common = ['node', str(tool)]
    freeze = common + ['freeze', '--input', str(root / 'v8-model-final-source/cases.json'),
        '--out', str(study), '--model-id', 'megatoken-v8-bounded-decoder-' + label,
        '--model-revision', checkpoint, '--settings', str(out / 'settings.json'),
        '--checkpoint', checkpoint, '--tokenizer', '7f52faca2fe82273a889023defd2f1a6fd6080a21096ec77e97f4798a0a370b2',
        '--origin', 'model', '--seed', '17', '--seed', '29', '--seed', '43',
        '--max-predictions', '4', '--max-generated', '8', '--max-outstanding', '1',
        '--max-stale-retries', '0', '--timeout-ms', '30000']
    subprocess.run(freeze, cwd=producer, env=env, check=True)
    execute = common + ['run', '--study', str(study / 'study.json'),
        '--cases', str(study / 'private-cases.json'), '--out', str(result),
        '--megatoken', str(consumer), '--served', str(root / 'v8-native-bounded-fit' / label),
        '--python', str(root / 'native-venv/bin/python')]
    subprocess.run(execute, cwd=producer, env=env, check=True)
    report = json.loads((result / 'report.json').read_text())
    print(json.dumps({'model': label, 'summary': report['summary'], 'qualification': report['qualification']}), flush=True)
