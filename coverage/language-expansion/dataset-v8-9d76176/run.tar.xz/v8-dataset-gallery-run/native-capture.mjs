import {writeFileSync,appendFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {nativePolicy,nativeConsumer as invoke,close} from '../tracing-js-self/tools/semantic-v8-native-adapter.mjs';
export {nativePolicy,close};
let sequence=0;
export async function nativeConsumer(artifact){
  const id=String(++sequence).padStart(3,'0'),bytes=JSON.stringify(artifact)+'\n',
    sha256=createHash('sha256').update(bytes).digest('hex');
  writeFileSync(new URL('native-inputs/'+id+'.json',import.meta.url),bytes);
  const receipt=await invoke(artifact);
  if(receipt.sourceVerification.artifactSha256!==sha256)throw new Error('Exact native input hash differs');
  writeFileSync(new URL('native-inputs/'+id+'.receipt.json',import.meta.url),JSON.stringify(receipt,null,2)+'\n');
  appendFileSync(new URL('native-inputs/bindings.jsonl',import.meta.url),JSON.stringify({id,sha256,
    datasetBindingDigest:receipt.datasetBindingDigest,sourceId:artifact.sidecar.splitIdentity.sourceId})+'\n');
  return receipt;
}
