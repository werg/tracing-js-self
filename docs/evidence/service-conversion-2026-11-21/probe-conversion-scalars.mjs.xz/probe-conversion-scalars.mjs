import {encode} from './tracing-js-self/src/values.js';
let seed=0x13579bdf;const next=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed;};
const values=[],buffer=new ArrayBuffer(8),view=new DataView(buffer);
for(let i=0;i<3000;i++){view.setUint32(0,next());view.setUint32(4,next());const x=view.getFloat64(0);if(Number.isFinite(x))values.push(x);}
const text=['\u0085','\u180e','\ufeff','\ud800','0x'+'f'.repeat(9000),'0b'+'1'.repeat(9000),'9'.repeat(9000),'1e999999','1e-999999','-0','-0x0','+0b1','0o8','1_000','NaN','nan','INFINITY','Infinity','Infinity\u0000','0x1.1'];
for(let i=0;i<300;i++)text.push((i%2?'-':'')+'0.'+'0'.repeat(i)+'1'+(i%4?'':'e'+i));
console.log(JSON.stringify([...values,...text].map(x=>({input:encode(x),Number:encode(Number(x)),PropertyKey:encode(String(x))}))));
