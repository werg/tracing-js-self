import fs from 'node:fs';
import {verifyProtocolRegionTrainingCase} from './tracing-js-self/src/semantic/protocol-source-v8.js';
const cases={
  'null-exotic-getter':'let n=0;const k={get [Symbol.toPrimitive](){n++;return null;},toString(){n++;return "x";}};return {x:5}[k]+n;',
  'undefined-string-getter':'let n=0;const k={get toString(){n++;return undefined;},valueOf(){n++;return "x";}};return {x:5}[k]+n;',
  'inherited-getter':'let n=0;const p={get toString(){n++;return function(){return this.x;};}};const k=Object.create(p);k.x="v";return {v:5}[k]+n;',
  'inherited-mutation':'const p={toString(){this.valueOf=function(){return "x";};return {};},valueOf(){return "y";}};const k=Object.create(p);return {x:5,y:8}[k];',
  'shared-method':'let n=0;const method=function(){n++;return this.x;};const a={toString:method,x:"a"},b={toString:method,x:"b"};return {a:2,b:3}[a]+{a:2,b:3}[b]+n;',
  'getter-arrow-this':'const k={x:"bad",get toString(){return ()=>this.x;}};return {bad:8}[k];',
  'symbol-result-key':'const s=Symbol("k"),k={toString(){return s;}};return {[s]:9}[k];',
  'bigint-result-key':'const k={toString(){return 9007199254740993n;}};return {"9007199254740993":8}[k];',
  'get-number-mutate-prototype':'const p={toString(){return "7";}};const k={get valueOf(){Object.setPrototypeOf(this,p);return undefined;}};return Number(k);',
  'get-string-mutate-prototype':'const p={valueOf(){return "x";}};const k={get toString(){Object.setPrototypeOf(this,p);return undefined;}};return {x:8}[k];',
  'reentrant-getter':'let n=0;const k={get toString(){if(n++===0){const inner={toString(){return "y";}};({y:1})[inner];}return ()=>"x";}};return {x:8}[k]+n;',
  'computed-destructuring':'const k={toString(){return "x";}};const {[k]:v}={x:8};return v;',
  'computed-parameter':'const k={toString(){return "x";}};function f({[k]:v}){return v;}return f({x:8});',
  'object-spread-getter':'let n=0;const k={toString(){n++;return "x";}};const obj={get [k](){return 8;}};return {...obj}.x+n;',
  'for-in-body-key':'const k={toString(){return "x";}};let total=0;for(const n in {a:1,b:2}){total+={x:4}[k];}return total;',
  'array-in-proto':'const p=[1,2],k=Object.create(p);return {["1,2"]:8}[k];',
  'null-proto-own':'const k=Object.create(null);k.toString=function(){return "x";};return {x:8}[k];',
  'function-proto-own':'const p=function(){};p.toString=function(){return "x";};const k=Object.create(p);return {x:8}[k];',
  'shared-getter-returns-ref':'const method=function(){return this.x;};const desc={get:function(){return method;}};const a={x:"a"},b={x:"b"};Object.defineProperty(a,"toString",desc);Object.defineProperty(b,"toString",desc);return {a:3,b:5}[a]+{a:3,b:5}[b];',
  'async-method-return-fallback':'const k={async toString(){return "bad";},valueOf(){return "x";}};return {x:8}[k];',
  'generator-method-fallback':'const k={*toString(){yield "bad";},valueOf(){return "x";}};return {x:8}[k];',
  'array-map-inside-key':'const k={toString(){return ["x"].map(function(x){return x;})[0];}};return {x:8}[k];',
  'getter-catch-finally-return':'let n=0;const k={get toString(){try{throw "x";}catch(e){n++;return function(){return e;};}finally{n++;}}};return {x:8}[k]+n;',
  'method-throw-mutated-object':'const e={v:1},k={toString(){e.v=2;throw e;}};try{return {}[k];}catch(x){return x===e?x.v:0;}'
};
const rows=[];
for(const [id,body]of Object.entries(cases)){
 const source='"use strict";function run(){'+body+'}',fixture={id,source,entry:'run',args:[],fixture:{calls:[]},family:'conversion-review:'+id};
 let native;try{native=new Function(source+';return run();')();}catch(e){native={error:e.name,message:e.message};}
 try{const checked=await verifyProtocolRegionTrainingCase(fixture);rows.push({id,native,status:checked.status,reason:checked.reason,artifact:checked.exported});console.log(JSON.stringify({id,native,status:checked.status,reason:checked.reason}));}
 catch(e){rows.push({id,native,error:e.message});console.log(JSON.stringify({id,native,error:e.message}));}
}
fs.writeFileSync('/workspace/scratch/dc03db3a26f3/probe-conversion-source.json',JSON.stringify(rows));
