# Namespace public/native admission: source-grounded design review

This is a read-only design review following the owned namespace repairs. It is
not a qualified public profile, a native admission receipt, or a claim that the
module work is complete. The producer repair is local commit `cc47deb`; root is
publishing it separately. No public schema or consumer namespace admission was
changed.

## What was established and repaired

The existing owned namespace representation stores generated getter closures
internally. Observable `Object.getOwnPropertyDescriptor` already returns the
required **live data descriptor**: current value, writable/enumerable true,
configurable false. The implementation storage is not an observable accessor
descriptor and should not become one in the public wire format.

Three reproducible owned errors were repaired before considering wire expansion:

1. Reflection on absent names inherited by the implementation dictionaries
   (`__proto__`, `constructor`, `toString`, `valueOf`, `hasOwnProperty`) incorrectly
   attempted to invoke an export getter. These now return undefined.
2. `Reflect.defineProperty` incorrectly returned false for invalid getter/setter
   values or mixed data/accessor descriptor fields. Descriptor conversion now
   checks fields in specification order and throws the appropriate guest TypeError.
3. Cyclic uninitialized exports could produce ReferenceError before an invalid
   descriptor produced its required TypeError. Descriptor validation now precedes
   the namespace live-cell read. Valid descriptors still encounter the real TDZ.

The repaired tests independently execute the original module graph in Node,
compare owned outcomes, JSON-round-trip the complete archive, validate it, and
perform exact replay. The targeted six-file module selection passes 55 tests,
including valid ordinary/class/generator/async function descriptor controls.
Callable proxies are not an existing supported owned target: proxy allocation
admits ordinary objects, arrays and other noncallable proxies only. Existing
descriptor getters and inherited descriptor fields remain explicit profile
refusals; neither their side effects nor their errors are fabricated.

The original failing source examples and results are preserved in
`namespace-design-targeted-sources.json` and
`namespace-design-targeted-results.json`. The repaired results are separately
preserved in `namespace-design-fixed-results.json`: four owned/native agreements,
with all four public namespace projections still refused. These are probes,
not clean-published-revision qualification.

## Existing authority and limits

`src/evaluated-modules.js` resolves imports/reexports, preserves live cell aliases,
sorts namespace export names by UTF-16 code units, excludes missing or ambiguous
star exports, and rejects unresolved explicit exports and named imports. It
materializes namespaces only when identity, dynamic access, method receivers,
reflection, or mutation requires an actual object. Static reads and `typeof`
already have narrower qualified paths.

`src/runtime.js` retains a distinct `module-namespace` object, null prototype,
non-extensibility, immutable export-name inventory, live getter continuations,
and the fixed `Symbol.toStringTag` descriptor. Own keys are export names followed
by that symbol. `Set` returns false, delete succeeds only for absent properties,
and definition uses SameValue plus namespace attribute restrictions. Descriptor
inspection, hasOwn, keys, and integrity operations can read an uninitialized live
cell and must preserve TDZ and early termination. Existing JSON restore tests
exercise retained getters, reflection, and freeze continuations.

The source verifier in `src/semantic/module-v8.js` deliberately refuses
`requiresModuleNamespace` before public export. Its independent original ESM
worker currently establishes the final outcome, not a namespace-operation
observation stream. The ordinary source compiler also refuses namespace heap
objects; ordinary source execution does not install the reserved namespace
constructor automatically. Disabling either refusal would bypass real missing
work.

The retained ECMA-262 17.0 artifact establishes namespace key ordering and
descriptor behavior. Node 24's numeric-name namespace ordering differs: owned
`["10","2","a"]` versus native `["2","10","a"]`. The owned lexical ordering
should not be changed to obtain a green differential. This population must remain
an explicit reference-disagreement boundary unless an independent matching
authority is provided. Other preserved native module discrepancies include
same-origin namespace reexport diamonds and ambiguity resolution.

## Proposed representation boundary

A coherent extension should keep a **distinct namespace heap kind**, rather than
silently widen ordinary-object acceptance:

| Public fact | Proposed representation/check |
| --- | --- |
| Identity | An allocated module instance namespace identity, shared by all aliases |
| Exports | Immutable sorted rows mapping export-name strings to canonical live binding-cell identities |
| Cells | A declared module-cell inventory plus existing live locals; absence of an initialized value must distinguish known TDZ from an unknown reference |
| Attributes | Derived null prototype, non-extensibility, fixed export descriptor attributes, and fixed Module toStringTag |
| Reads | Resolve the current canonical cell value at the operation; do not snapshot a value at namespace allocation |
| Descriptors | Materialize fresh ordinary data-descriptor objects from the live read; do not expose generated getter closures |
| Ordering | Compare UTF-16 code units explicitly in Python; never use the existing numeric-first ordinary own-key ordering |
| Checkpoints | Validate export/cell identity consistency, immutable inventories, current cell initialization, and any pending inspection/definition continuation |

The existing protocol has string cell identities, shared `locals`, and closure
capture aliases; this should be reused where valid. It currently does not retain
a declaration inventory sufficient to distinguish a module TDZ from an unknown
cell. Adding a namespace merely as `{properties: snapshots}` loses liveness;
publishing `{accessors: generated getters}` lies about observable descriptors.
Namespace-valued exports also need an explicit instantiation plan: a compiler
temporary const that is not initialized yet is not proof that the original module
namespace identity is unavailable. Unsupported instantiation states should be
refused until modeled.

## Independent native checker work

The Python consumer's ordinary property helper snapshots stored values, its own
key helper orders numeric keys first, and ordinary writable data descriptors
permit mutations that namespaces reject. Ordinary hasOwn tests presence without
reading a live cell, and the existing full descriptor record loses the distinction
between an omitted attribute and false. These require namespace-specific dispatch
and exact record semantics, not one additional object-kind string.

Existing property operations may be reused only when their declared meanings
remain exact. Creation, live descriptor results, partial definition requests and
multi-step inspection need explicit records or a precisely validated continuation.
Namespace Set must remain false despite writable:true descriptors. Prototype,
extensibility, ownKeys, identity aliases, imports, absent exports, SameValue and
JSON restoration each need independent malformed-state controls. The normal host
graph codec should continue rejecting namespace escape.

The generated getter is an owned implementation of a cell read. A public adapter
may collapse it only after proving that it is the exact compiler-created cell
read with no guest effects. Otherwise its receiver, callee, capture, completion
and continuation must be represented and checked. Existing owned JSON replay
alone is not independent native checkpoint qualification.

## Hardest remaining source authority work

The native source observer must operate on the **original ESM graph and actual
native module namespace objects**. Synthetic ordinary objects with getters, or
the producer's linked script, cannot establish namespace exotic semantics. A
bounded source instrumentation plan should preserve key evaluation, receiver
identity, callee-before-argument order, errors, aliases, and module initialization.
It must associate observed namespace identities and live binding changes with
an independently checked module graph and export resolution, rather than trusting
producer getter metadata. Fresh original-source regeneration and mismatched
trace/graph controls must pass before changing module projection admission.

Intrinsic TypeError/ReferenceError source metadata is another separate gate.
Component fault derivation, native final-output agreement, or a caught error name
does not by itself establish exact source-bound exception identity and ordering.
The first bounded profile may refuse unsupported fault or instantiation paths,
provided the complete selected denominator and its dispositions remain visible.

Import mutation remains an owned linker-profile refusal even where native ESM
would execute and catch TypeError; do not label it as matching runtime behavior.
Dynamic import, asynchronous module scheduling, namespace host escape, descriptor
getter/inherited-field effects, numeric export-name reference disagreements, and
unresolved/ambiguous export cases remain explicit boundaries until separately
implemented and qualified.

## Suggested next increment

Start with the source observer and declared module-cell/namespace identity plan
for a small preserved population: dynamic live reads before/after a mutation,
reexport aliases, a namespace-valued export, own data descriptors, absent names,
prototype/extensibility/ownKeys, SameValue definition controls, strict mutation,
and cyclic uninitialized cells. Retain reference-disagreement and unsupported
rows in that population. Only after the observer can independently classify the
original sources should producer projection and a parallel Python state checker
be implemented. The current repairs remove owned errors but do not complete any
of those public/native gates.
