"""Read-only, no-model probes for the existing plan section 8 route inventory.

This is engineering evidence about dispatch/census/import boundaries, not source
admission, production-tokenizer admission, optimizer execution, or model quality.
Run from the consumer checkout with PYTHONPATH=src and a data-worker environment.
"""

from __future__ import annotations

import ast
import base64
import copy
import gzip
import hashlib
import importlib.abc
import json
import sqlite3
import subprocess
import sys
import traceback
from collections import Counter
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace

ROOT = Path.cwd()
report = {
    "schema": "semantic-cutover-route-probe/1",
    "scope": "Read-only consumer dispatch, behavior census, and actual native-episode coverage entry",
    "consumerRevision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "optimizerSteps": 0,
    "modelCalls": 0,
    "admissionClaim": False,
    "files": {},
}


def source(name):
    raw = (ROOT / name).read_bytes()
    report["files"][name] = {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}
    return raw.decode()


def function(name, function_name):
    """Execute the unchanged route function body without importing torch.

    Only the inference decorator is omitted. This does not exercise runtime
    creation, source validation, locking, or actual orchestration execution.
    """
    tree = ast.parse(source(name), filename=name)
    node = next(item for item in tree.body if isinstance(item, ast.FunctionDef) and item.name == function_name)
    node.decorator_list = []
    compiled = ast.Module(body=[node], type_ignores=[])
    namespace = {}
    exec(compile(ast.fix_missing_locations(compiled), name, "exec"), namespace)
    return namespace[function_name]


methods = ("initialize", "select", "commit", "reject", "complete", "cancel", "checkpoint", "restore",
           "open_orchestration", "step_orchestration", "status_orchestration", "cancel_orchestration")
calls = []


def method(name):
    def invoke(*args, **kwargs):
        calls.append({"method": name, "args": args, "kwargs": kwargs})
        return {"routed": name}
    return invoke


adapter = SimpleNamespace(**{name: method(name) for name in methods})
old_dispatch = function("scripts/serve_selected_semantic.py", "dispatch")
new_dispatch = function("scripts/serve_semantic_v8.py", "dispatch")
request = {"id": "route-probe", "op": "open-orchestration", "session": "session",
           "proposals": [], "origin": "model"}
old_result = old_dispatch(adapter, copy.deepcopy(request))
try:
    new_result = new_dispatch(adapter, copy.deepcopy(request))
except ValueError as error:
    new_result = {"refused": type(error).__name__, "message": str(error)}
report["orchestrationDispatch"] = {
    "mode": "Original dispatch bodies; inference decorator omitted; stub endpoint records routing only",
    "request": request, "oldResult": old_result, "v8Result": new_result, "calls": calls,
    "v8NativeMethods": [node.name for node in ast.walk(ast.parse(source("src/megatoken/semantic_model_v8.py")))
                        if isinstance(node, ast.FunctionDef) and node.name in methods],
}

# Exercise the exact nested launch configuration guard without importing the
# unrelated model/GPU runtime. No prepared paths or launch assets are admitted.
from megatoken.io import read_mapping
from megatoken.training.config import TrainConfig
import os

value = read_mapping(ROOT / "configs/train/semantic-v8-production.example.yaml")
source("configs/train/semantic-v8-production.example.yaml")
value["semantic_v8_policy"] = {
    "schema": "semantic-training-policy/8", "producerRevision": "a" * 40,
    "consumerRevision": "b" * 40, "registryDigest": "c" * 64,
}
config = TrainConfig.from_dict(value, expand_data=False)
launch = ast.parse(source("src/megatoken/training/semantic_launch.py"))
configuration = next(node for node in ast.walk(launch)
                     if isinstance(node, ast.FunctionDef) and node.name == "configuration")
namespace = {"TrainConfig": TrainConfig, "value": value, "os": os}
exec(compile(ast.fix_missing_locations(ast.Module(body=[configuration], type_ignores=[])),
             "src/megatoken/training/semantic_launch.py", "exec"), namespace)
try:
    namespace["configuration"]()
    launch_result = {"accepted": True}
except ValueError as error:
    launch_result = {"accepted": False, "message": str(error)}
report["v8ProductionLaunchConfiguration"] = {
    "mode": "Actual TrainConfig and unchanged launch configuration guard; no asset/model/GPU checks",
    "trainConfigValid": True, "purpose": config.purpose, "phase": config.phase,
    "semanticV8Policy": config.semantic_v8_policy is not None,
    "semanticExperiment": config.semantic_experiment, "launchGuard": launch_result,
}

corpus_source = source("src/megatoken/data/semantic_corpus_v8.py")
census = next(node for node in ast.parse(corpus_source).body
              if isinstance(node, ast.FunctionDef) and node.name == "semantic_behaviors_v8")
vocabulary = sorted({node.value for node in ast.walk(census)
                     if isinstance(node, ast.Constant) and isinstance(node.value, str)
                     and node.value.startswith("semantic_") and node.value != "semantic_execution"})
stages = json.loads(source("src/megatoken/data/stages.json"))
required = stages["phases"]["SE"]["constraints"]["required_behaviors"]
from megatoken.data.coverage import Coverage, require_coverage

source("src/megatoken/data/coverage.py")
source("src/megatoken/data/storage.py")
source("src/megatoken/data/semantic_corpus.py")
source("src/megatoken/training/engine.py")
scope = "train|semantic_execution|"
ceiling = SimpleNamespace(parts=[SimpleNamespace(manifest={"behavior_coverage": {
    "original_families": {scope + name: 1 for name in vocabulary},
    "original_family_ids": {scope + name: ["ceiling-family"] for name in vocabulary},
}})])
try:
    require_coverage(ceiling, required, {"semantic_execution": 1})
    ceiling_result = {"accepted": True}
except ValueError as error:
    ceiling_result = {"accepted": False, "message": str(error)}
report["productionSEBehaviorCeiling"] = {
    "mode": "Function-literal output vocabulary upper bound, not a prepared/admitted corpus",
    "required": required, "v8CensusVocabulary": vocabulary,
    "impossibleRequiredBehaviors": sorted(set(required) - set(vocabulary)),
    "ordinaryCoverageGate": ceiling_result,
}

blocked = {
    "megatoken.data.algorithm_v7", "megatoken.data.detailed_v7",
    "megatoken.data.detailed_harness_v7", "megatoken.data.detailed_context_v7",
    "megatoken.data.semantic_harness_v6", "megatoken.data.semantic_contract",
    "megatoken.data.semantic_contract_v7", "megatoken.training.semantic_budget",
}


class NoLegacyWire(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname in blocked:
            raise AssertionError("Legacy wire dependency: " + fullname)


assert not blocked.intersection(sys.modules)
sys.meta_path.insert(0, NoLegacyWire())
from megatoken.data.native_v8 import prepare_native_v8_training, validate_v8_artifact
from megatoken.data.semantic_corpus_v8 import semantic_behaviors_v8
from megatoken.generation.codec import ByteCodec

fixture_name = "tests/fixtures/semantic-regions-v8.json.gz.b64"
raw = (ROOT / fixture_name).read_bytes()
report["files"][fixture_name] = {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}
document = json.loads(gzip.decompress(base64.b64decode(raw)))
first = document.get("examples", document.get("cases", [document]))[0]
artifact = first.get("artifact", first)
validated = validate_v8_artifact(artifact)
episode, training = prepare_native_v8_training(artifact, codec=ByteCodec.byte_fallback())
annotations = json.loads(episode.supervision.annotations_json)
annotations["semantic_execution"]["publicArtifact"] = {"public": artifact["public"], "contexts": artifact["contexts"]}
episode = replace(episode, supervision=replace(episode.supervision, annotations_json=json.dumps(annotations)))
direct_behaviors = semantic_behaviors_v8(episode)
assert not blocked.intersection(sys.modules)
try:
    with sqlite3.connect(":memory:") as connection:
        coverage = Coverage(connection)
        coverage.add(episode, "train", "semantic_execution")
        coverage_result = {"accepted": True, "report": coverage.report()}
except (AssertionError, ValueError) as error:
    coverage_result = {"accepted": False, "type": type(error).__name__, "message": str(error),
                       "traceback": traceback.format_exc()}
report["actualV8CoverageWithoutLegacy"] = {
    "fixture": fixture_name, "id": first.get("id", artifact.get("id")),
    "nativeChecks": validated["checks"], "maskValidation": training["maskValidation"],
    "codec": "Engineering byte fallback; no production tokenizer/admission claim",
    "directV8Behaviors": sorted(direct_behaviors), "coverageAdd": coverage_result,
    "legacyModulesLoaded": sorted(blocked.intersection(sys.modules)),
}

from megatoken.data.recipes import resolve_stream_producer
source("src/megatoken/data/recipes.py")
routes = []
for version in (None, "v8"):
    try:
        producer = resolve_stream_producer("semantic_execution", semantic_version=version)
        result = {"callable": producer.__module__ + ":" + producer.__name__}
    except (AssertionError, ValueError) as error:
        result = {"refused": type(error).__name__, "message": str(error)}
    routes.append({"requestedSemanticVersion": version, **result})
report["defaultProducerRoutingUnderLegacyAbsence"] = routes

print(json.dumps(report, ensure_ascii=False, indent=2))
