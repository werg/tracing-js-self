// Public entry routing probe only. No source/native admission or model claim.
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {LEGACY_V8_CLIENT_FILES} from '../tracing-js-self/src/corpus/installed-v8-qualification.mjs';

const root=new URL('../tracing-js-self/',import.meta.url),cwd=root.pathname;
const loader='const blocked='+JSON.stringify(LEGACY_V8_CLIENT_FILES)+';'+
  'export async function resolve(s,c,next){const r=await next(s,c);'+
  'if(blocked.some(p=>new URL(r.url).pathname.endsWith("/"+p)))'+
  'throw new Error("legacy dependency: "+r.url);return r;}';
const entries=['tracing-js-self','tracing-js-self/training','tracing-js-self/semantic',
  'tracing-js-self/semantic/v8','tracing-js-self/natlang-selected',
  'tracing-js-self/capabilities/node','tracing-js-self/storage/node'];
const rows=[];
for(const entry of entries){
  const result=spawnSync(process.execPath,['--no-warnings','--experimental-loader',
    'data:text/javascript,'+encodeURIComponent(loader),'--input-type=module','-e',
    'const m=await import('+JSON.stringify(entry)+');console.log(JSON.stringify({entry:'+JSON.stringify(entry)+
      ',exports:Object.keys(m).length,wire:m.WITNESS_VERSION??m.ALGORITHM_TRACE_VERSION??m.REGION_TRACE_VERSION??null}));'],
    {cwd,encoding:'utf8',timeout:30000,maxBuffer:1024*1024});
  rows.push({entry,status:result.status===0?'imported-without-listed-legacy-clients':'refused-legacy-dependency',
    exitCode:result.status,result:result.status===0?JSON.parse(result.stdout):null,
    error:result.status===0?null:result.stderr.split('\n').find(line=>line.startsWith('Error:'))??result.stderr.trim()});
}
const revision=spawnSync('git',['rev-parse','HEAD'],{cwd,encoding:'utf8'}).stdout.trim();
const files={};
for(const name of ['package.json','src/training/index.js','src/semantic/index.js','src/semantic/index-v8.js',
  'src/natlang-selected.js','src/corpus/installed-v8-qualification.mjs']){
  const bytes=readFileSync(new URL(name,root));
  files[name]={bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')};
}
console.log(JSON.stringify({schema:'semantic-cutover-public-entry-probe/1',producerRevision:revision,
  scope:'Public package import routing under the existing installed-qualification absence list; no execution/parity claim',
  blocked:LEGACY_V8_CLIENT_FILES,rows,files},null,2));
