"""Draft route evidence for the existing cutover plan, not a replacement plan."""
from __future__ import annotations

import hashlib
import json
import subprocess
from collections import Counter
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
ROOTS = {"producer": BASE / "tracing-js-self", "consumer": BASE / "megatoken"}
rows = []


def row(identity, repo, title, paths, current, replacement, replacement_paths, tests,
        missing, *, command=None, status="legacy-route-open", scope="production-semantic",
        fresh=None, plan=None):
    rows.append({
        "id": identity, "repository": repo, "surface": title,
        "planSection": plan or ("8.1" if repo == "producer" else "8.2"),
        "workPackages": [1, 17], "paths": paths, "scope": scope,
        "currentBehavior": current, "status": status,
        "v8Replacement": {"description": replacement, "paths": replacement_paths},
        "executableEvidence": {"paths": tests, "command": command,
            "status": "existing tests/tooling inspected; not re-executed by this inventory"},
        "freshEvidence": fresh or [], "remainingParityOrEvidence": missing,
    })


row("P01", "producer", "Public training package entry",
    ["package.json", "src/training/index.js", "src/training/model-driver.js"],
    "tracing-js-self/training exports the V6 witness codec, controller, harness, selected driver, source admission and session APIs; imports still require removed legacy clients.",
    "Explicit tracing-js-self/semantic/v8 exposes direct V8 controller/lifecycle/source compiler/region harness/model driver. This is an alternative entry, not a completed migration of training's public behavior.",
    ["src/semantic/index-v8.js", "src/semantic/controller-v8.js", "src/semantic/lifecycle-v8.js", "src/semantic/selected-execution-v8.js"],
    ["test/semantic-public-entry-v8.test.js", "test/semantic-lifecycle-v8.test.js", "test/training-model-driver.test.js"],
    ["Switch the default semantic entry only after its selected/orchestration/Natlang behavior map passes V8 replacements; remove eager legacy exports at that point."],
    command="node --test test/semantic-public-entry-v8.test.js test/semantic-lifecycle-v8.test.js test/training-model-driver.test.js",
    fresh=["producer-entries-final.json"])
row("P02", "producer", "Aggregate semantic entry",
    ["package.json", "src/semantic/index.js"],
    "tracing-js-self/semantic eagerly exports V7 algorithm/detailed APIs alongside V8 APIs. Its ALGORITHM_TRACE_VERSION remains semantic-trace/7 and import fails with old trace-codec absent.",
    "Explicit semantic/v8 has direct exports and no aggregate import.", ["src/semantic/index-v8.js"],
    ["test/semantic-public-entry-v8.test.js", "test/semantic-installed-qualification-v8.test.js"],
    ["Default aggregate routing/removal remains undone; installed V8-only qualification does not prove the aggregate entry works."],
    command="node --test test/semantic-public-entry-v8.test.js test/semantic-installed-qualification-v8.test.js", fresh=["producer-entries-final.json"])
row("P03", "producer", "Selected Natlang environment and native bindings",
    ["src/natlang-selected.js", "src/natlang-selected.d.ts", "package.json"],
    "createNatlangSelectedEnvironment constructs SelectedExecutionHarness and SelectedModelDriver from the V6 training clients. It supports retained modules, exported closures, callable/cell/resource envelopes, callback reentry, timeout and close.",
    "RegionExecutionHarness/RegionSelectedModelDriver provide V8 foundations and callback/recovery support; no V8-backed Natlang environment entry exists.",
    ["src/semantic/region-harness.js", "src/semantic/selected-execution-v8.js"],
    ["test/natlang-selected-executor.test.js", "test/semantic-source-return-callback-v8.test.js", "test/semantic-durable-return-callback-v8.test.js"],
    ["Port the actual wrapper/environment path and all nine existing selected Natlang tests; generic V8 callback tests do not prove wrapper compilation, live cells and exported-function identity parity."],
    command="node --test test/natlang-selected-executor.test.js test/semantic-source-return-callback-v8.test.js test/semantic-durable-return-callback-v8.test.js", fresh=["producer-entries-final.json"])
row("P04", "producer", "Process selector and coordinator RPC",
    ["src/training/megatoken-process.js", "src/training/orchestration-evaluation.js"],
    "createMegatokenProcessSelector defaults representation=compact/V6 and exposes openOrchestration, stepOrchestration, statusOrchestration and cancelOrchestration plus selected request commit/recovery.",
    "createNativeV8ProcessSelector implements select/commit/reject/complete/cancel/checkpoint/restore; it does not replace coordinator RPC.",
    ["src/semantic/native-process-v8.js", "src/semantic/selected-execution-v8.js"],
    ["test/semantic-native-process-v8.test.js", "test/training-orchestration-evaluation.test.js", "test/semantic-selected-execution-v8.test.js"],
    ["Typed child creation/join/progress/completion/cancellation/restore remains a real parity gap. Pair with C13-C15, not a text-codec rename."],
    command="node --test test/semantic-native-process-v8.test.js test/training-orchestration-evaluation.test.js test/semantic-selected-execution-v8.test.js", fresh=["consumer-routes-final.json"])
row("P05", "producer", "Native Node/browser capability entries",
    ["src/host/selected-capabilities-node.js", "src/host/selected-capabilities-browser.js", "src/host/graph-codec.js"],
    "Adapters are host capability functions with explicit session/realm/resource ownership; they do not directly import a V6 wire codec. The existing full real-network/DOM selected tests are wired through historical selected clients.",
    "The same host interface is used by direct V8 lifecycle; V8 callback, ingress and effect gates exist.",
    ["src/semantic/lifecycle-v8.js", "src/semantic/region-harness.js"],
    ["test/selected-node-capabilities.test.js", "test/selected-browser-capabilities.test.js", "test/selected-capability-lifecycle.test.js", "test/browser/selected-dom.test.mjs", "test/semantic-lifecycle-v8.test.js"],
    ["Run the real filesystem/HTTP/socket/DOM lifetime and cancellation interactions via V8 selected execution before retiring historical selected tests; generic service fixtures are narrower."],
    status="neutral-adapter-parity-pending", fresh=["producer-entries-final.json"])
row("P06", "producer", "Neutral execution internals and wire separation",
    ["src/semantic/execution-controller.js", "src/semantic/execution-lifecycle.js", "src/semantic/execution-driver.js", "src/semantic/region-harness.js"],
    "Shared selected state/lifecycle/driver are neutral implementations; historical clients wrap them. Direct V8 uses its own codec and continuation.",
    "Implemented direct state/lifecycle and public V8 source/replay/checkpoint path.",
    ["src/semantic/controller-v8.js", "src/semantic/lifecycle-v8.js", "src/semantic/detail-v8.js"],
    ["test/semantic-lifecycle-v8.test.js", "test/semantic-public-entry-v8.test.js", "test/semantic-installed-qualification-v8.test.js"],
    ["Neutral core acceptance still needs complete production route parity; success of explicit V8 entry does not migrate P01-P04."],
    status="implemented-scoped-v8", command="node --test test/semantic-lifecycle-v8.test.js test/semantic-public-entry-v8.test.js")
row("P07", "producer", "Default training generator and every registered recipe",
    ["package.json", "tools/generate-effectful-training.mjs", "src/corpus/training-candidates.mjs", "src/corpus/campaign-identity.mjs", "src/training/recipe-fixtures.js"],
    "npm run training:generate defaults to engineering; engineering, training-v4, benchmark-v1, real-source and generated-v1 feed V6 effectful compiler/admission and V6 campaign identity. Training/benchmark recipes include repeated session cases and lifecycle-dependent data.",
    "qualify-semantic-v8 declares complete all/interoperability populations; buildRegionDataset/verifyRegionTrainingCase can generate V8 source-bound artifacts.",
    ["tools/qualify-semantic-v8.mjs", "src/semantic/dataset-v8.js", "src/semantic/compiler-v8.js", "fixtures/semantic-regions/qualification.js"],
    ["test/semantic-v8-dataset.test.js", "test/semantic-qualification-population-v8.test.js"],
    ["No registered old-recipe-to-V8 complete data/parity report exists; 665/66 fixed V8 populations are not automatically the same recipe/task denominator or coordinator training corpus."],
    command="node tools/qualify-semantic-v8.mjs --population all --inputs all --out OUT --megatoken CONSUMER --python PYTHON --tokenizer TOKENIZER --native-policy POLICY")
row("P08", "producer", "Default training source admission/recheck",
    ["tools/verify-effectful-admission.mjs", "src/training/effectful-admit.js", "src/training/effectful-session.js"],
    "training:recheck uses V6 source/private/public binding. Training index's native policy and session admission remain V6.",
    "V8 recheckRegionEvidence/admitRegionEvidence and recheck-semantic-native-source.mjs cover exact V8 artifacts.",
    ["src/semantic/compiler-v8.js", "src/semantic/source-admission-v8.js", "tools/recheck-semantic-native-source.mjs"],
    ["test/semantic-native-v8.test.js", "test/semantic-public-entry-v8.test.js"],
    ["Migrate defaults and regenerated policies/receipts; keep source, public-native engineering and production admission claims distinct."],
    command="node --test test/semantic-native-v8.test.js test/semantic-public-entry-v8.test.js")
row("P09", "producer", "Default freeze/evaluate experiment commands",
    ["tools/freeze-selected-evaluation.mjs", "tools/run-selected-evaluation.mjs", "src/training/selected-evaluation.js", "src/training/orchestration-evaluation.js"],
    "training:freeze/evaluate freeze V6 cohorts and evaluate actual selected V6 runs; --with-orchestration adds real coordinator behavior.",
    "semantic:v8:experiment freeze/run, execution-study-v8 and selected-execution-v8 provide frozen source-qualified V8 experiments with original selected bytes and separate provenance.",
    ["tools/run-semantic-v8-experiment.mjs", "src/semantic/execution-study-v8.js", "src/semantic/selected-execution-v8.js"],
    ["test/semantic-execution-study-v8.test.js", "test/semantic-selected-execution-v8.test.js", "test/training-orchestration-evaluation.test.js"],
    ["Full old cohort/behavior mapping, coordinator experiments and budget/analysis parity are not yet demonstrated by the V8 runner."],
    command="node --test test/semantic-execution-study-v8.test.js test/semantic-selected-execution-v8.test.js")
row("P10", "producer", "Default inspection and retained session campaign",
    ["tools/inspect-selected-harness.mjs", "tools/semantic-session-campaign.mjs", "src/training/semantic-diagnostics.js", "src/training/render-orchestration.js"],
    "training:inspect/session-campaign imports V6 harness/codec/session verification and legacy diagnostics.",
    "V8 public replay/checkpoint plus selected driver history and renderAlgorithmV8Record exist; no equivalent default V8 diagnostics/campaign command is established.",
    ["src/semantic/region-harness.js", "src/semantic/render-v8.js", "src/semantic/selected-execution-v8.js"],
    ["test/semantic-lifecycle-v8.test.js", "test/semantic-selected-history-v8.test.js", "test/semantic-host-recovery-v8.test.js"],
    ["Map every campaign/recovery/diagnostic output to V8 and retain original case statuses; no retirement based on a pure replay-only control."])
row("P11", "producer", "Coverage default and explicit baseline/representation comparisons",
    ["tools/generate-capability-ledger.mjs", "tools/current-v6-baseline.mjs", "tools/compare-semantic-representations.mjs", "tools/semantic-trace-gallery.mjs", "src/training/semantic-trace-gallery.js"],
    "coverage:current defaults --version7; explicit baseline:v6 measures V6. Semantic gallery/default historical comparison tooling still consumes old representations.",
    "coverage:v8 explicitly selects version8; qualify-semantic-v8 --population gallery and measure-semantic-v8 retain V8 source/native/token scopes.",
    ["tools/generate-capability-ledger.mjs", "tools/qualify-semantic-v8.mjs", "tools/measure-semantic-v8.mjs"],
    ["test/capability-ledger.test.js", "test/semantic-serving-costs.test.js"],
    ["Switch only active coverage defaults. Keep frozen V6/V7 baseline readers explicitly historical, outside the installed active execution path."],
    scope="active-default-plus-historical-comparison")
row("P12", "producer", "V7 explicit admission/export routes",
    ["tools/qualify-semantic-v7.mjs", "tools/export-algorithm-training.mjs", "tools/verify-algorithm-admission.mjs", "src/semantic/dataset-v7.js", "src/semantic/causal-lm-v7.js"],
    "semantic:v7:admit/export/recheck are still runnable V7 production-candidate routes.",
    "semantic:v8:admit/export plus dataset-v8/causal-lm-v8 implement V8 equivalents.",
    ["tools/export-semantic-v8.mjs", "src/semantic/dataset-v8.js", "src/semantic/causal-lm-v8.js"],
    ["test/semantic-causal-lm-v8.test.js", "test/semantic-v8-dataset.test.js"],
    ["Remove active V7 registrations after replacing their behavior tests; preserve only clearly historical artifact readers if needed."],
    command="node --test test/semantic-causal-lm-v8.test.js test/semantic-v8-dataset.test.js")
row("P13", "producer", "Owned VM, archive CLI and ordinary module APIs",
    ["bin/tracing.js", "src/index.js", "src/runtime.js", "src/validation.js", "src/replay.js", "src/causal.js", "src/natlang.js", "src/modules.js", "src/evaluated-modules.js", "src/evaluated-module-session.js", "src/evaluated-module-facade.js", "src/agent-model.js", "src/native-worker-agents.js"],
    "Main tracing-js-self CLI run/demo/validate/replay/causal and root package target owned execution/archive APIs, not selected semantic-trace/6. Shared graph/profile helpers under training/ are not proof of legacy wire use.",
    "Retain these owned reference/runtime/observational facilities as explicitly allowed by plan2.2. Selected module source projection uses module-v8 separately.",
    ["src/semantic/module-v8.js"], ["test/semantic-module-v8.test.js", "test/evaluated-module-namespace-exotics.test.js"],
    ["No wholesale V8 rename/removal of the owned CLI or archive formats. Full module semantic/source coverage remains its own plan work."],
    status="exempt-owned-runtime", scope="owned-reference-and-archive", fresh=["producer-entries-final.json"])
row("P14", "producer", "Selected action, ingress and checkpoint recovery",
    ["src/training/harness-v4.js", "src/training/intent-journal.js", "src/storage/node.js"],
    "Historical selected harness/intent journal remain callable, alongside version-neutral and V8-specific durable stores.",
    "Direct V8 lifecycle + region restore, ingress journals, selected checkpoint histories, terminal histories, return-callback recovery and native transport recovery are implemented.",
    ["src/semantic/lifecycle-v8.js", "src/semantic/region-harness.js", "src/semantic/selected-execution-v8.js", "src/storage/node.js"],
    ["test/semantic-durable-action-recovery-v8.test.js", "test/semantic-durable-ingress-v8.test.js", "test/semantic-durable-return-callback-v8.test.js", "test/semantic-selected-history-automatic-v8.test.js", "test/semantic-selected-history-tail-v8.test.js"],
    ["Map complete old operational/child/Natlang cases before default retirement; these strong scoped V8 tests do not restore arbitrary native resource/callback registries."],
    status="implemented-scoped-v8")
row("P15", "producer", "Controlled service admission and owner/terminal fencing",
    ["src/host/selected-service.js", "src/storage/selected-service-journal.js", "src/storage/selected-service-fence-journal.js", "docs/DURABLE_SELECTED_SERVICES.md"],
    "Shared wrapper and durable basic/fenced service journals are explicit bounded APIs, with cross-process at-most-once admission and ordered newest-owner/terminal fencing.",
    "Implemented V8 usable service boundary; immutable payload identity, exact retained scalar outcome, unknown refusal, winner-only capability and recovered outcome directory sync.",
    ["src/storage/selected-service-fence-journal.js"],
    ["test/semantic-service-fence-v8.test.js", "test/semantic-durable-service-v8.test.js"],
    ["No generic remote transaction rollback, automatic selected-history/service transaction, arbitrary callback/resource restoration, or forced cancellation of already-admitted work. Supervisor ordering remains explicit."],
    status="implemented-scoped-v8", fresh=["../tracing-js-self/docs/evidence/service-fence/evidence.json"],
    command="node --test test/semantic-service-fence-v8.test.js test/semantic-durable-service-v8.test.js")
row("P16", "producer", "Private release packaging and restore drill",
    ["tools/package-semantic-release.py", "tools/restore-semantic-release.py", "tools/restore-release-campaign.mjs", "tools/verify-release-campaign.mjs", "tools/select-release-training.mjs"],
    "Packager/restore still bind native-admission-policy-v6, V6 source/native admission, semantic-dedup.sqlite and semantic-v6-release.tar.gz. Original producer verifier is authenticated before replay.",
    "V8 installed-package qualification and individual checkpoint/history recovery tools exist, but are not an equivalent complete prepared release archive/restorer.",
    ["tools/qualify-installed-v8.mjs", "tools/qualify-v8-checkpoint-history.mjs", "tools/qualify-v8-terminal-history.mjs"],
    ["test/release-campaign.test.js", "test/restore-release-campaign.test.js", "tools/native-consumer/test_release_bundle.py", "tools/native-consumer/test_release_restore.py", "test/semantic-installed-qualification-v8.test.js"],
    ["Implement V8 full release materialization, dependency/policy/data/source audit, fresh restore and effect-safe deployment drill. Installed npm source qualification is not this operational release gate."], plan="8.6")
row("P17", "producer", "Installed absence and recurring CI registrations",
    ["src/corpus/installed-v8-qualification.mjs", "tools/qualify-installed-v8.mjs", ".github/workflows/semantic-v8.yml", ".github/workflows/megatoken-consumer.yml", ".github/workflows/selected-harness-v4.yml", ".github/workflows/semantic-v7.yml", ".github/workflows/native-conditioning-parity.yml"],
    "V8 full installed qualifier removes18 legacy clients and tests complete665/66 input inventories via explicit semantic/v8. Separate historical V6/V7 selected/CI workflows remain registered.",
    "Existing full installed/paired workflow is the current V8 evidence vehicle; final pair qualification is in progress under root ownership.",
    ["tools/qualify-installed-v8.mjs", ".github/workflows/semantic-v8.yml"],
    ["test/semantic-installed-qualification-v8.test.js", "test/semantic-public-entry-v8.test.js"],
    ["No proof that default training/semantic/Natlang entries work without legacy files; preserve unmatched old behavior tests until corresponding V8 gates exist. Do not use cancelled/historical jobs as current passes."],
    status="implemented-scoped-v8", plan="8.6", fresh=["producer-entries-final.json"])
row("P18", "producer", "Contract generators and active native policies",
    ["package.json", "tools/generate-semantic-contract.mjs", "tools/generate-semantic-algorithm-contract.mjs", "tools/generate-semantic-execution-contract.mjs", "tools/generate-semantic-region-contract.mjs", "contracts/native-admission-policy-v6.json", "contracts/semantic-native-policy-v7.json", "contracts/semantic-native-policy-v8.json"],
    "semantic:contract checks V7 algorithm/execution definitions; contracts:check also checks historical selected harness and host contracts. V6/V7 native policies remain bound to their active old routes; V8 policy is separate and root is finalizing its exact native pin.",
    "semantic:v8:contract verifies V8 complete source-bound contract/interoperability output; V8 source/native admission reads the V8 policy.",
    ["tools/generate-semantic-region-contract.mjs", "contracts/semantic-native-policy-v8.json"],
    ["test/semantic-native-v8.test.js", "test/semantic-public-entry-v8.test.js"],
    ["Default contract command and installed active policy registry must converge only after route retirement. Historical fixtures/reference expectations can remain distinct from active runtime imports."],
    command="npm run semantic:v8:contract")
row("P19", "producer", "Retained cost and comparison tools",
    ["tools/measure-retained-serving.mjs", "tools/compare-serving-costs.mjs"],
    "semantic:retained-costs meters frozen prior representations and semantic:compare-costs checks exact original comparison artifacts. These are historical evidence readers, not selected dispatch defaults.",
    "measure-semantic-v8 meters active V8 qualification output; comparison tool can retain honest before/after evidence.",
    ["tools/measure-semantic-v8.mjs"],
    ["test/retained-serving-costs.test.js", "test/serving-cost-comparison.test.js", "test/qualification-costs-v8.test.js"],
    ["Keep historical input bytes/pins explicit, with no active legacy runtime dependency hidden behind current-serving labels; remeasure final changed pair where required."],
    status="historical-evidence-reader", scope="historical-comparison")
row("P20", "producer", "Campaign selection, native prepared sampler and learning freeze",
    ["tools/select-admitted-campaign.mjs", "tools/verify-exact-public-aliases.mjs", "tools/verify-exact-public-aliases.py", "tools/derive-native-prepared-sampler.py", "tools/native_prepared_sampler.py", "tools/diagnostic_training_inventory.py", "tools/freeze-learning-experiment.mjs", "tools/run-causal-lm-evaluation.mjs"],
    "Manual production-data/learning tools still bind effectful V6 admission, exact-public alias metadata, V6 prepared episode reproduction and selected V6 evaluation. The prepared sampler explicitly lists legacy native modules and context/contract files in its authenticated identity.",
    "V8 frozen family registry/dataset binding and execution-study-v8 cover core source membership and selected evaluation, but not every sampler/alias/exposure/analysis command.",
    ["src/semantic/family-registry-v8.js", "src/semantic/dataset-v8.js", "src/semantic/execution-study-v8.js", "tools/run-semantic-v8-experiment.mjs"],
    ["test/test_native_prepared_sampler.py", "test/test_exact_public_aliases.py", "test/test_learning_artifacts.py", "test/training-learning-experiment.test.js", "test/semantic-v8-dataset.test.js"],
    ["Preserve exact original exclusions, complete accepted inventory, global family split, token caps and checkpoint/exposure decision rules when building active V8 counterparts. Historical V6 readers can remain explicitly historical."],
    command="python -m pytest -q test/test_native_prepared_sampler.py test/test_exact_public_aliases.py test/test_learning_artifacts.py")
row("P21", "producer", "Legacy native fitting and conditioning diagnostics",
    ["tools/fit-native-semantic-record.py", "tools/run-optimization-smoke.py", "tools/native_semantic_capture.py", "tools/native_input_parity.py", "tools/native_two_boundary_probe.py", "tools/probe-native-conditionals.py", "tools/build-native-probe-input.mjs", "tools/advance-native-probe-prefix.mjs", "tools/native-pure-output-model.py"],
    "Bounded diagnostic tools use real historical V6 adapter/prefix/teacher-boundary paths or explicitly bound old semantic capture configuration. They are not production launch evidence and some intentionally measure source/input-only output rather than selected execution.",
    "Native fit_semantic_v8.py and V8 continuation parity tests, plus qualify-ordinary-v8-lifecycle and selected history/closed-session tools, provide direct V8 diagnostics.",
    ["tools/qualify-ordinary-v8-lifecycle.mjs", "tools/qualify-v8-checkpoint-history.mjs", "tools/qualify-v8-closed-sessions.mjs"],
    ["test/test_native_conditional_probe.py", "test/test_native_input_parity.py", "test/test_native_two_boundary_probe.py", "test/test_optimization_smoke_selection.py"],
    ["Label old diagnostics as historical and keep outside active default installed semantic paths; retain the exact tensor/token/state parity questions in V8 replacements, without treating a fit as generalization."],
    status="legacy-diagnostic-route", scope="bounded-engineering-diagnostics",
    command="python -m pytest -q test/test_native_conditional_probe.py test/test_native_input_parity.py test/test_native_two_boundary_probe.py test/test_optimization_smoke_selection.py")
row("P22", "producer", "Legacy source regression, inspection and fixture generators",
    ["tools/check-real-source-cases.mjs", "tools/check-semantic-boundaries.mjs", "tools/inspect-semantic-reasoning.mjs", "tools/audit-teacher-mutations.mjs", "tools/generate-native-regression-fixtures.mjs", "tools/generate-selected-continuity-v4.mjs", "tools/generate-selected-harness-v4.mjs", "tools/validate-semantic-v6-emission.mjs"],
    "These manually callable engineering/source-regression/fixture commands import the old effectful admission/harness/witness stack; some comments still describe earlier V5 names although actual imports are V6 clients.",
    "V8 source compiler/admission, complete V8 qualifier/interoperability generator and public-entry source mutation controls cover direct V8 foundations.",
    ["src/semantic/source-admission-v8.js", "tools/qualify-semantic-v8.mjs", "tools/generate-semantic-region-contract.mjs"],
    ["test/semantic-effectful-teacher-v8.test.js", "test/semantic-public-entry-v8.test.js", "test/semantic-lifecycle-v8.test.js"],
    ["Map actual mutation, lifecycle continuity and real-source cases to V8 before removing old engineering lanes. Shared owned interpreter mutation controls may remain reference tests; old wire invocation must not stay hidden in active V8 tooling."],
    scope="engineering-route-and-fixture-generation")
row("P23", "producer", "Ordinary explicit V8 qualifier's common worker",
    ["tools/qualify-semantic-v8.mjs", "src/corpus/generation-process.mjs", "tools/generation-worker.mjs"],
    "qualify-semantic-v8 calls runGenerationProcess, which launches generation-worker. That worker eagerly imports training/effectful-admit.js and effectful-session.js before choosing traceVersion8; session tasks always choose the legacy session verifier.",
    "The installed qualifier uses its separate direct public-V8 installed-v8-worker and proves that narrower source/projection/replay route can work without old clients.",
    ["tools/installed-v8-worker.mjs", "tools/qualify-installed-v8.mjs", "src/semantic/source-reference.js"],
    ["test/generation-process.test.js", "test/semantic-installed-qualification-v8.test.js", "test/semantic-qualification-population-v8.test.js"],
    ["Extract neutral reference helpers/use direct V8 worker for the ordinary V8 qualifier, make legacy imports lazy only for explicit old tasks, and add an actual V8 worker process absence test. Current installed-worker pass does not cover this common-worker path."],
    status="concrete-v8-tooling-dependency", fresh=["producer-entries-final.json"])
row("P24", "producer", "Summary/comprehension research commands",
    ["tools/semantic-summary-experiment.mjs", "tools/semantic-comprehension-study.mjs"],
    "Summary tool explicitly advertises an experimental summary contract, not a production V5 adapter. Comprehension tool freezes/scores a separate reader taskset; neither is an ordinary selected wire-serving default.",
    "Keep research endpoints explicitly scoped; active V8 selected execution and frozen studies remain separate.",
    ["src/semantic/comprehension-study.js", "src/semantic/execution-study-v8.js"],
    ["test/semantic-execution-study-v8.test.js"],
    ["Actual complete frozen reader/model responses and registered analysis are still required before quality/readability adoption claims; do not replace them with a route import test."],
    status="research-scope-distinct", scope="research-and-reader-comprehension")

row("C01", "consumer", "Console prepare and generic data package",
    ["pyproject.toml", "src/megatoken/cli.py", "src/megatoken/data/cli.py", "src/megatoken/data/__init__.py", "src/megatoken/data/prepare.py"],
    "megatoken prepare uses generic source manifests/adapters and common prepared storage. It is not an implicit V6 semantic compiler. Semantic-specific preparation is separately registered in recipes/scripts.",
    "Keep generic prepare; V8 semantic input uses prepare_semantic_v8.py and source/native admission.",
    ["scripts/prepare_semantic_v8.py", "src/megatoken/data/semantic_corpus_v8.py"],
    ["tests/test_semantic_v8_training_policy.py", "tests/test_semantic_v8_export_without_legacy.py"],
    ["Do not relabel generic JSON/multimodal preparation as V6. Its semantic export dependency was real and fixed in C04."],
    status="neutral-generic-route", scope="generic-data-plus-explicit-semantic-preparation")
row("C02", "consumer", "Default semantic stream catalog and source inventory",
    ["src/megatoken/data/recipes.py", "src/megatoken/data/inventory.py", "scripts/audit_training_inventory.py"],
    "STREAM_PRODUCERS.semantic_execution points to semantic_corpus:prepare_semantic_corpus; resolve_stream_producer without semantic_version uses V6. Source inventory reports that default producer.",
    "resolve_stream_producer(..., semantic_version='v8') explicitly resolves semantic_corpus_v8:prepare_semantic_corpus_v8.",
    ["src/megatoken/data/recipes.py", "src/megatoken/data/semantic_corpus_v8.py"],
    ["tests/test_semantic_v8_training_policy.py", "tests/test_v8_entrypoints_without_legacy.py"],
    ["Switch catalog default only after SE/SC curriculum/coordinator and all registered production prep paths pass. Data-source inventory is not a semantic route/parity ledger."],
    fresh=["consumer-routes-final.json"])
row("C03", "consumer", "Default semantic corpus preparation/admission scripts",
    ["scripts/admit_semantic_harness.py", "scripts/prepare_semantic_corpus.py", "scripts/validate_semantic_corpus.py", "src/megatoken/data/semantic_corpus.py", "src/megatoken/data/semantic_admission.py", "src/megatoken/data/semantic_harness_v6.py", "src/megatoken/data/semantic_context.py", "src/megatoken/data/semantic_contract.py", "src/megatoken/data/witness_v6.py"],
    "Named default semantic prepare/admit/validate scripts use V6 contracts/receipts/private source recheck and native physical preparation.",
    "admit_semantic_v8.py and prepare_semantic_v8.py perform explicit independent V8 public/source/native/tokenizer checks and strict prepared bindings.",
    ["scripts/admit_semantic_v8.py", "scripts/prepare_semantic_v8.py", "src/megatoken/data/native_v8.py", "src/megatoken/data/semantic_corpus_v8.py"],
    ["tests/test_admit_semantic_v8.py", "tests/test_native_v8_without_legacy.py", "tests/test_semantic_v8_training_policy.py"],
    ["Default scripts/receipt consumers remain legacy; replace registrations with V8 and preserve source-to-native failure controls. Final current native pin/CLI qualification is root-owned."])
row("C04", "consumer", "Ordinary V8 export behavior census",
    ["src/megatoken/data/coverage.py", "src/megatoken/data/storage.py", "src/megatoken/data/semantic_corpus_v8.py"],
    "Before fix: actual V8 export entered Coverage.add -> semantic_corpus -> semantic_contract and failed with legacy clients blocked. Fixed schema-directed lazy import routes V8 straight to semantic_behaviors_v8; V6/V7 fallback remains.",
    "Implemented narrow fix in local699f3df, published by root as776519e69b32b11927edd60eab84c77cebfe2a9c. Existing public/native records, masks, data and coverage remain byte-identical with11 old modules blocked.",
    ["src/megatoken/data/coverage.py"], ["tests/test_semantic_v8_export_without_legacy.py"],
    ["Engineering controls inject source/tokenizer audit boundaries. Full real-tokenizer/source CLI and torch-dependent integration belong to final paired CI; no production-admission claim from this test."],
    status="fixed-this-session", command="python -m pytest -q tests/test_semantic_v8_export_without_legacy.py",
    fresh=["export-absence-before.log", "export-absence-after.log", "export-coverage-integration.log", "consumer-routes-before.json", "consumer-routes-final.json"])
row("C05", "consumer", "Effectful/common curriculum preparation and lifecycle collection",
    ["scripts/prepare_semantic_experiments.py", "scripts/collect_semantic_lifecycle.py", "src/megatoken/data/semantic_lifecycle.py", "src/megatoken/data/semantic_recipe_preparation.py"],
    "Curriculum prep imports V6 prepare/source verifier and legacy semantic_budget supply validation; collector records actual coordinator/child native lifecycle labels.",
    "V8 source/callback/recovery artifacts and preparation exist; no equivalent V8 coordinator lifecycle collector or complete old curriculum migration is present.",
    ["scripts/prepare_semantic_v8.py", "src/megatoken/data/semantic_corpus_v8.py"],
    ["tests/test_semantic_recipe_preparation.py", "tests/test_semantic_orchestration.py", "tests/test_semantic_v8_continuation_parity.py"],
    ["Port actual native child lifecycle collection and source-replay binding, then regenerate exact complete family-separated data; labels may not be inferred from mere child-like callback invocation IDs."])
row("C06", "consumer", "Production stage behavior requirements",
    ["src/megatoken/data/stages.json", "src/megatoken/data/semantic_corpus_v8.py", "src/megatoken/data/coverage.py", "src/megatoken/training/engine.py", "src/megatoken/training/readiness.py"],
    "SE requires code/tool/async/callback/repeated-invocation/child/source-reread/recovery families. V8 census has no possible output for repeated_invocation, child, source_reread. Even the entire possible V8 output vocabulary fails the ordinary SE coverage gate.",
    "Actual retained V8 invocations and callbacks already exist; no complete SE curriculum/census replacement.",
    ["src/megatoken/data/semantic_corpus_v8.py", "src/megatoken/data/native_v8.py"],
    ["tests/test_semantic_v8_continuation_parity.py", "tests/test_native_v8_lifecycle_authority.py", "tests/test_semantic_v8_training_policy.py"],
    ["Derive repeated/source-read labels only from real validated records, supply source-qualified train+validation families, and implement typed coordinator-child parity for semantic_child. Do not weaken SE requirements or manufacture tags."],
    status="concrete-production-parity-blocker", fresh=["consumer-routes-final.json"])
row("C07", "consumer", "Checked-in canonical training presets and planner",
    ["configs/train/semantic-common.example.yaml", "configs/train/semantic-effectful.example.yaml", "configs/semantic/train-seed-17.json", "configs/semantic/train-seed-29.json", "configs/semantic/train-seed-43.json", "configs/semantic/experiment-plan-v4.json", "scripts/plan_semantic_training.py"],
    "Canonical common/effectful and seed17/29/43 presets select semantic_experiment schema4 compact V6 cohorts; planner materializes the old experiment matrix.",
    "Explicit semantic-v8.example.yaml diagnostic and semantic-v8-production.example.yaml SC policy templates exist.",
    ["configs/train/semantic-v8.example.yaml", "configs/train/semantic-v8-production.example.yaml"],
    ["tests/test_semantic_v8_training_policy.py", "tests/test_semantic_training_state.py"],
    ["No active V8 SE template/corpus matrix replacing old per-seed/common/effectful budgets; production assets/placeholders still require qualification. SC template validation alone is not launch readiness."])
row("C08", "consumer", "Ordinary train/readiness policy and optimizer path",
    ["src/megatoken/cli.py", "src/megatoken/training/config.py", "src/megatoken/training/engine.py", "src/megatoken/training/readiness.py"],
    "megatoken train/train-check are shared. semantic_v8_policy explicitly selects strict V8 codec/data/pins before optimizer work; semantic_experiment chooses V6 and cannot coexist with V8. V7 policy remains separately supported.",
    "Implemented ordinary V8 preflight and training; existing diagnostic SC two-update workflow uses the ordinary CLI.",
    ["src/megatoken/training/semantic_v8.py", "src/megatoken/semantic_lineage_v8.py"],
    ["tests/test_semantic_v8_training_policy.py", "tests/test_semantic_v8_training_lifecycle.py", "tests/test_semantic_v8_lineage.py"],
    ["Keep strict no-override admission. Production SE supply/C06 and full production launch/C12 remain unqualified; current ordinary qualification explicitly uses diagnostic SC/tiny."],
    status="implemented-opt-in-v8", command="python -m pytest -q tests/test_semantic_v8_training_policy.py tests/test_semantic_v8_training_lifecycle.py tests/test_semantic_v8_lineage.py")
row("C09", "consumer", "Ordinary checkpoint resume and stage transitions",
    ["src/megatoken/training/engine.py", "src/megatoken/training/checkpoint.py", "src/megatoken/loading.py", "src/megatoken/semantic_lineage_v8.py"],
    "Shared resume/pipeline paths retain and validate V8 training lineage/policy; legacy experiment state still has its own lazy V6 restoration branch.",
    "Implemented ordinary V8 checkpoint/update/resume identity and dataset lineage controls.",
    ["src/megatoken/semantic_lineage_v8.py", "src/megatoken/training/semantic_v8.py"],
    ["tests/test_semantic_v8_training_lifecycle.py", "tests/test_semantic_v8_lineage.py"],
    ["Full production curriculum transitions, distributed restart under load and matched frozen experiment exposure still require complete parity evidence."],
    status="implemented-opt-in-v8")
row("C10", "consumer", "Ordinary export/load served bundle",
    ["src/megatoken/cli.py", "src/megatoken/served.py", "src/megatoken/loading.py"],
    "megatoken export and ServedBundle validate V8 lineage and raw codec for V8 checkpoints. Legacy semantic_budget export remains lazy only for semantic_experiment checkpoints.",
    "Implemented V8 lineage-preserving export/load; serving uses explicit V8 semantic adapter after bundle load.",
    ["src/megatoken/semantic_lineage_v8.py", "src/megatoken/semantic_model_v8.py"],
    ["tests/test_semantic_v8_training_lifecycle.py", "tests/test_semantic_v8_lineage.py", "tests/test_semantic_v8_serving_identity.py"],
    ["The shared generic console serve does not select the V8 semantic RPC automatically. Default semantic serving convergence is C13/C14."],
    status="implemented-opt-in-v8")
row("C11", "consumer", "DiLoCo initialize/worker/coordinator export",
    ["src/megatoken/cli.py", "src/megatoken/training/diloco_export.py", "src/megatoken/training/engine.py", "src/megatoken/semantic_lineage_v8.py"],
    "Generic distributed routes carry semantic_v8_policy/lineage and validate matching export. Existing production semantics launch qualifier still assumes old experiment budgets.",
    "V8 policy/lineage code exists in distributed initialize/export and ordinary worker.",
    ["src/megatoken/training/diloco_export.py", "src/megatoken/semantic_lineage_v8.py"],
    ["tests/test_semantic_v8_lineage.py", "tests/test_semantic_launch.py"],
    ["No fresh end-to-end V8 production coordinator/worker restart proof in this inventory; old launch validation cannot accept valid V8 config, C12."],
    status="implemented-scoped-v8")
row("C12", "consumer", "Production semantic launch qualifier",
    ["scripts/qualify_semantic_launch.py", "src/megatoken/training/semantic_launch.py", "src/megatoken/training/config.py"],
    "qualify_launch imports legacy SemanticExperimentConfig/validate_stage_supply and requires semantic_experiment nonnull. TrainConfig forbids semantic_experiment with semantic_v8_policy. Thus a valid V8 production config is unconditionally refused by this existing operational route.",
    "train-check has V8 policy/data checks; it is not equivalent to the launch qualifier's donor, repository, bootstrap, coordinator, hindsight and hardware gates.",
    ["src/megatoken/training/readiness.py", "src/megatoken/training/semantic_v8.py", "src/megatoken/semantic_lineage_v8.py"],
    ["tests/test_semantic_launch.py", "tests/test_semantic_v8_training_policy.py"],
    ["Implement a direct V8 launch branch preserving all existing independent asset/runtime gates and V8 resume/bootstrap lineage. Changing only the configuration guard would still run old V6 supply/budget validators."],
    status="concrete-production-parity-blocker", fresh=["consumer-routes-final.json"])
row("C13", "consumer", "Default selected semantic JSONL server and public adapter",
    ["scripts/serve_selected_semantic.py", "src/megatoken/semantic_model_adapter.py"],
    "Named selected server constructs SelectedSemanticInference over MultiTrackRuntime and uses V6 prefixes, witness requests, typed child tracks and retained orchestration/subscriptions.",
    "serve_semantic_v8.py constructs NativeSemanticInferenceV8, validates public replay and stages original candidates transactionally until commit.",
    ["scripts/serve_semantic_v8.py", "src/megatoken/semantic_model_v8.py"],
    ["tests/test_semantic_model_v8.py", "tests/test_serve_semantic_v8.py", "tests/test_semantic_v8_serving_restore.py", "tests/test_semantic_v8_continuation_parity.py"],
    ["Consolidate entry only after typed orchestration/child/request/default model driver parity; V8 correctly supports retained callbacks and should not be described as lacking all callback support."],
    fresh=["consumer-routes-final.json"])
row("C14", "consumer", "Native coordinator open/step/status/cancel operations",
    ["src/megatoken/semantic_orchestration.py", "scripts/serve_selected_semantic.py", "scripts/serve_semantic_v8.py", "src/megatoken/semantic_model_v8.py"],
    "Old server's four orchestration operations create native child work, wait for actual completion, publish exact results and cancel/restore. V8 server rejects the same operation name as Unknown native v8 RPC operation; V8 class has no such methods.",
    "V8 selected driver/public-prefix and generic neutral track registry are foundations, but no public V8 coordinator replacement exists.",
    ["src/megatoken/lifecycle.py", "src/megatoken/semantic_model_v8.py"],
    ["tests/test_semantic_orchestration.py", "tests/test_semantic_v8_serving_restore.py"],
    ["This is the hardest next bounded implementation: native typed child proposal/creation/join/exact completion/cancel/restore with original model-selected coordinator bytes and V8 source/state authority."],
    status="concrete-production-parity-blocker", fresh=["consumer-routes-final.json"])
row("C15", "consumer", "Native execution context and selected request dispatch",
    ["src/megatoken/multitrack_runtime.py", "src/megatoken/data/semantic_request.py", "src/megatoken/lifecycle.py"],
    "register_execution_context requires program and invocation schema semantic-execution/6. bootstrap_execution expects old fields. dispatch_semantic_requests dynamically imports witness_v6 and validates original request witness bytes before host dispatch.",
    "V8 public context/source replay and producer-side RegionExecutionHarness broker validate V8 operations; generic track registry is reusable.",
    ["src/megatoken/data/prefix_v8.py", "src/megatoken/data/native_v8.py", "src/megatoken/semantic_model_v8.py"],
    ["tests/test_semantic_model_adapter.py", "tests/test_semantic_orchestration.py", "tests/test_native_v8_lifecycle_authority.py"],
    ["Define a neutral immutable typed child binding carrying V8 source/invocation/public-prefix authority; port bootstrap and dispatch without turning unacknowledged candidates into tool authority."],
    status="concrete-production-parity-blocker")
row("C16", "consumer", "Ordinary generic console serve/generate",
    ["src/megatoken/cli.py", "src/megatoken/multitrack_service.py", "src/megatoken/multitrack_runtime.py"],
    "megatoken serve/generate load a generic served bundle into MultiTrackService, for text/multimodal sessions and tools. They do not implicitly construct either selected semantic adapter.",
    "Keep generic runtime; explicit V8 semantic server wraps the same runtime with semantic candidate/commit rules.",
    ["scripts/serve_semantic_v8.py", "src/megatoken/semantic_model_v8.py"],
    ["tests/test_serve_semantic_v8.py", "tests/test_semantic_v8_serving_identity.py"],
    ["Do not claim the generic console is a V6 semantic route. If a canonical semantic console command is required, wire explicit V8 semantics only after C13-C15 parity."],
    status="neutral-generic-route", scope="generic-serving-plus-explicit-semantic-adapter")
row("C17", "consumer", "Canonical semantic control metadata/instructions",
    ["src/megatoken/controls.py", "src/megatoken/semantic_model_adapter.py", "src/megatoken/data/semantic_context.py"],
    "Unversioned semantic_execution_metadata/semantic_selection_instruction name semantic-execution/6 and semantic-trace/6. Explicit V8 counterparts are used by native_v8 and semantic_model_v8.",
    "semantic_execution_metadata_v8 and semantic_selection_instruction_v8 preserve ordinary training/serving control alignment.",
    ["src/megatoken/controls.py", "src/megatoken/data/native_v8.py", "src/megatoken/semantic_model_v8.py"],
    ["tests/test_prediction_prefix_v8.py", "tests/test_semantic_v8_continuation_parity.py"],
    ["Retire/redirect old default helpers only alongside old adapter/context callers; exact conditioning parity must remain, not cosmetic version substitutions."],
    status="dual-route-default-legacy")
row("C18", "consumer", "Live session checkpoint, closed tombstones and native continuation",
    ["src/megatoken/semantic_model_adapter.py", "src/megatoken/semantic_model_v8.py", "src/megatoken/semantic_checkpoint_v8.py"],
    "Old adapter snapshots V6 tracks/orchestration/subscriptions. V8 adapter reconstructs acknowledged public/history state, native recurrent/RNG continuation and closed-session tombstones; candidates are speculative until exact public acknowledgement.",
    "Implemented V8 session/closed-session restore, retained callbacks, rejected candidate isolation and ordinary inference identity.",
    ["src/megatoken/semantic_model_v8.py", "src/megatoken/semantic_checkpoint_v8.py"],
    ["tests/test_semantic_v8_serving_restore.py", "tests/test_semantic_v8_closed_session_restore.py", "tests/test_semantic_v8_continuation_parity.py", "tests/test_native_v8_lifecycle_authority.py"],
    ["Old coordinator/child reserved/runnable/waiting/terminal recovery and arbitrary external resource restoration are not proven by these V8 session controls."],
    status="implemented-scoped-v8")
row("C19", "consumer", "Legacy inference sanity and orchestration validator commands",
    ["scripts/check_semantic_inference.py", "scripts/validate_semantic_orchestration.py"],
    "check_semantic_inference launches serve_selected_semantic and expects V6 selected-model-output/2. Orchestration validator adapts V6 harness and old evaluation result schemas.",
    "qualify_semantic_v8_lifecycle.py and V8 selected driver studies test actual V8 bundle/selection/restore paths.",
    ["scripts/qualify_semantic_v8_lifecycle.py", "scripts/serve_semantic_v8.py"],
    ["tests/test_semantic_v8_training_lifecycle.py", "tests/test_semantic_v8_serving_restore.py", "tests/test_semantic_orchestration.py"],
    ["Replace both commands' exact outcome/parity gates; V8 lifecycle check explicitly acknowledges no generated semantic record and is not a complete coordinator success proof."])
row("C20", "consumer", "Frozen experiment budgets, evaluation and analysis",
    ["scripts/evaluate_semantic.py", "scripts/analyze_semantic_evaluation.py", "src/megatoken/training/semantic_budget.py", "src/megatoken/training/semantic_evaluation.py", "src/megatoken/training/semantic_analysis.py"],
    "Default semantic experiment budget/evaluation pipeline requires V6 compact episode/contract, source replay, old cohorts and engineering receipt; it separately distinguishes controlled/fixed/trained runs.",
    "Producer execution-study-v8/run-semantic-v8-experiment plus native fit/lifecycle diagnostics retain V8 candidates, costs and success scopes.",
    ["scripts/fit_semantic_v8.py", "scripts/qualify_semantic_v8_lifecycle.py"],
    ["tests/test_fit_semantic_v8.py", "tests/test_semantic_v8_lineage.py", "tests/test_semantic_training_state.py", "tests/test_semantic_analysis.py"],
    ["Complete frozen study, diversity, fixed-token/example/compute budgeting and family-aware statistical analysis parity remain missing; toy fitting/two updates do not close learned-adoption gates."])
row("C21", "consumer", "Explicit V7 import/preparation routes",
    ["scripts/admit_semantic_v7.py", "scripts/prepare_semantic_v7.py", "scripts/check_semantic_v7_training.py", "src/megatoken/data/semantic_corpus_v7.py", "src/megatoken/training/semantic_v7.py", "src/megatoken/data/detailed_v7.py", "src/megatoken/data/algorithm_v7.py"],
    "Versioned V7 scripts, training policy, detailed/algorithm validators remain registered and runnable.",
    "V8 native/data/training modules are direct independent paths; shared scalar semantic primitives have been extracted.",
    ["scripts/admit_semantic_v8.py", "scripts/prepare_semantic_v8.py", "src/megatoken/data/semantic_primitives.py", "src/megatoken/training/semantic_v8.py"],
    ["tests/test_native_v8_without_legacy.py", "tests/test_v8_entrypoints_without_legacy.py", "tests/test_semantic_v8_export_without_legacy.py"],
    ["Remove active V7 registry/CLI modules only after coverage/parity map is satisfied; retaining old normative vectors as non-runtime test data is a separate decision."])
row("C22", "consumer", "Native wheel and paired CI qualification",
    [".github/workflows/ci.yml", ".github/workflows/semantic-v8.yml", ".github/workflows/semantic-contract.yml", ".github/workflows/selected-harness-v4.yml", "tests/test_v8_entrypoints_without_legacy.py"],
    "Installed wheel gate imports three explicit V8 script entrypoints with eight old modules blocked. Native absent-wire gate executes public native replay. Before C04 neither exercised actual V8 prepared export under absence. Old V6 selected/coordinator workflows still run.",
    "New C04 export regression adds actual call-path evidence with11 blocked modules and three representation/lifecycle cases; root final paired CI preserves full inventories.",
    ["tests/test_semantic_v8_export_without_legacy.py", "tests/test_native_v8_without_legacy.py", ".github/workflows/semantic-v8.yml"],
    ["tests/test_v8_entrypoints_without_legacy.py", "tests/test_native_v8_without_legacy.py", "tests/test_semantic_v8_export_without_legacy.py"],
    ["Import-only success is insufficient for dynamic dependencies; final installed ordinary prep/train/export/serve/canonical defaults must actually execute with legacy absent."],
    status="implemented-scoped-v8", fresh=["export-absence-before.log", "export-absence-after.log"], plan="8.6")
row("C23", "consumer", "Dataset source manifests and model pack inventory",
    ["configs/packs/inventory.json", "src/megatoken/data/inventory.py", "scripts/audit_training_inventory.py"],
    "configs/data/sources*.json and pack inventory describe external/general multimodal supply, licenses and model assets. Incidental v6 words in dataset names are not semantic wire selection. Procedural semantic default is C02.",
    "Keep source/asset inventory and its access/preparation/sampling evidence; use V8 semantic registry/bindings for generated semantic corpora.",
    ["src/megatoken/data/semantic_corpus_v8.py"], ["tests/test_semantic_v8_training_policy.py"],
    ["No fabricated V8 schema edits to unrelated datasets/model versions. Complete source-family provenance and actual selected supply remain required for V8 corpora."],
    status="exempt-generic-assets", scope="general-data-and-assets")

package = json.loads((ROOTS["producer"] / "package.json").read_text())
entries = []
for name, target in package["exports"].items():
    if name == "./training": status, maps = "legacy-default-v6", ["P01"]
    elif name == "./semantic": status, maps = "aggregate-v7-plus-v8", ["P02"]
    elif name == "./semantic/v8": status, maps = "explicit-v8", ["P01", "P06"]
    elif name == "./natlang-selected": status, maps = "legacy-default-v6", ["P03"]
    elif name.startswith("./capabilities/"): status, maps = "neutral-host-adapter", ["P05"]
    elif name == "./storage/node": status, maps = "neutral-and-v8-storage", ["P14", "P15"]
    else: status, maps = "owned-runtime-or-reference-scope", ["P13"]
    entries.append({"entry": name, "target": target, "status": status, "routeIds": maps})

files = {}
missing = []
for route in rows:
    for role, paths in (("implementation", route["paths"]),
                        ("replacement", route["v8Replacement"]["paths"]),
                        ("evidence", route["executableEvidence"]["paths"])):
        for name in paths:
            root = ROOTS[route["repository"]]
            path = root / name
            if not path.is_file():
                missing.append({"route": route["id"], "role": role, "path": name})
                continue
            raw = path.read_bytes()
            files[route["repository"] + ":" + name] = {
                "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw),
            }

def export_paths(target):
    if isinstance(target, str):
        yield target.removeprefix("./")
    elif isinstance(target, dict):
        for value in target.values():
            yield from export_paths(value)

for entry in entries:
    for name in export_paths(entry["target"]):
        path = ROOTS["producer"] / name
        raw = path.read_bytes()
        files["producer:" + name] = {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}

for route in rows:
    if route["executableEvidence"]["command"] is None:
        prefix = "node --test " if route["repository"] == "producer" else "python -m pytest -q "
        suffix = ".test.js" if route["repository"] == "producer" else ".py"
        test_paths = [path for path in route["executableEvidence"]["paths"] if path.endswith(suffix)]
        route["executableEvidence"]["command"] = prefix + " ".join(test_paths) if test_paths else None

script_mapping = {}
for name, command in package["scripts"].items():
    if any(token in name for token in ("training:", "semantic:", "coverage:", "baseline:v6")):
        maps = [route["id"] for route in rows if route["repository"] == "producer" and
                any(path.startswith("tools/") and path in command
                    for path in route["paths"] + route["v8Replacement"]["paths"])]
        script_mapping[name] = {"command": command, "routeIds": maps}

artifacts = {}
for path in sorted(OUT.iterdir()):
    if path.suffix in {".json", ".log", ".py", ".mjs"} and path.name not in {"route-inventory.json", "build-inventory.py"}:
        raw = path.read_bytes()
        artifacts[path.name] = {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}

inventory = {
    "schema": "semantic-cutover-route-inventory-draft/1",
    "status": "draft-for-existing-plan-work-packages-1-and-17",
    "governingPlan": "tracing-js-self/docs/plans/language-coverage-and-v6-cutover.md",
    "governingLedger": "tracing-js-self/docs/LANGUAGE_COVERAGE_V8_CUTOVER_STATUS.md",
    "planScope": "Sections2.2,8.1,8.2,8.6; this inventory supplies the requested parity map, not new acceptance criteria.",
    "revisionsAtInventory": {name: subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
                             for name, root in ROOTS.items()},
    "scope": {
        "included": "Every producer package export; semantic npm defaults and explicit older semantic commands; consumer ordinary prepare/train/resume/export/serve, semantic scripts/catalog/presets, selected orchestration and operational recovery/release surfaces named by the existing plan.",
        "excluded": "Unrelated owned VM/archive versions, observational trace/reference APIs, generic multimodal dataset/model version names and arbitrary internal helpers with no active route.",
        "evidenceRule": "Referenced tests/tooling are executable targets, not claimed current passes. Fresh probe/test evidence names exact limited scope; root owns final paired/hosted CI and publication SHAs.",
        "unknown": "External Natlang repository callers, downstream deployments, user launch assets and unrecorded model outcomes were not available/qualified by this two-repository inventory.",
    },
    "summary": {"routeGroups": len(rows), "producerPublicEntries": len(entries),
                "statuses": dict(Counter(route["status"] for route in rows)),
                "unresolvedPathReferences": missing},
    "publicProducerEntries": entries,
    "semanticProducerScripts": script_mapping,
    "consumerSemanticScripts": {path.relative_to(ROOTS["consumer"]).as_posix(): {
        "routeIds": [route["id"] for route in rows if route["repository"] == "consumer" and
                     path.relative_to(ROOTS["consumer"]).as_posix() in
                     route["paths"] + route["v8Replacement"]["paths"]]}
        for path in sorted((ROOTS["consumer"] / "scripts").glob("*semantic*.py"))},
    "routes": rows, "sourceFiles": files, "artifacts": artifacts,
    "freshResults": [
        {"artifact": "export-absence-before.log", "result": "1 targeted failure, old dynamic legacy corpus import,1.51s"},
        {"artifact": "export-absence-after.log", "result": "3 passed,20.46s; actual prepare/replay/export/reload; injected source/tokenizer audit boundaries"},
        {"artifact": "export-coverage-integration.log", "result": "8 passed,3 failed,21.32s; all3 failures missing local torch; no relabeling as passes"},
        {"artifact": "producer-entries-final.json", "result": "4 selected imports work without listed legacy clients; training/aggregate semantic/Natlang selected fail; actual ordinary worker task kind=source traceVersion=8 fails before compilation on eager effectful-admit.js; no model/parity claim"},
        {"artifact": "consumer-routes-final.json", "result": "V8 coverage repaired; default stream catalog, coordinator RPC, SE census ceiling and launch configuration guard remain concrete gaps"},
    ],
    "nextHardestIncrement": {
        "routes": ["P04", "C05", "C06", "C14", "C15"],
        "deliverable": "One source-bound native V8 coordinator with one typed child: original selected track_create -> acknowledged V8 child source/input bootstrap -> exact committed child return -> track_join wake -> progress -> terminal; checkpoint while reserved/waiting and restore without duplicate dispatch.",
        "designConstraints": [
            "Use shared neutral immutable child bindings and retain the V8 public-prefix/source identity; do not translate to an internal V6 wire.",
            "Coordinator original selected bytes/provenance and child semantic candidate acknowledgement are separate authorities; uncommitted candidates must not dispatch.",
            "Preserve budget, grant, child completion dependency, cancellation and terminal ownership checks from the existing old route.",
            "Port existing controlled lifecycle tests plus malformed actual-model output preservation. A controlled pass is engineering parity, not learned success.",
            "Only after source-bound replayable lifecycle rows exist may the V8 census emit semantic_child. Repeated invocation and source reread need equally concrete records.",
        ],
        "independentFollowup": "C12 V8 production launch branch preserving existing donor/asset/repository/bootstrap/coordinator/hardware gates; reuse V8 strict policy and lineage. This can be implemented independently of coordinator modeling.",
    },
}
(OUT / "route-inventory.json").write_text(json.dumps(inventory, indent=2) + "\n")

lines = [
    "# Draft production V6-to-V8 route and parity inventory", "",
    "This supplies the existing cutover plan's work packages1 and17 and section8 migration map. It does not redefine scope or claim default cutover. All producer exports are enumerated in the JSON companion, including the owned VM/archive APIs that section2.2 explicitly permits.", "",
    "## Findings that block default retirement", "",
    "1. **Native child orchestration has no V8 replacement.** The old producer selector and native server expose open/step/status/cancel coordinator operations and typed child create/join/completion/restore. The V8 server has no matching operations; its native runtime still requires V6 observed child contexts and request witnesses on these old routes. V8 retained callbacks already work, and are credited separately.",
    "2. **Production effectful-stage supply cannot pass with current V8 census.** The ordinary stage requires repeated invocation, child execution, and source reread. None is in the V8 census's possible output vocabulary. The retained probe offers every possible V8 census output to the real ordinary coverage gate and it still refuses those three exact requirements. Current ordinary lifecycle qualification uses diagnostic SC/tiny and disables the production mixture, so it cannot close this gap.",
    "3. **The existing production launch qualifier cannot accept a valid V8 policy.** Its configuration guard requires a legacy semantic_experiment, while TrainConfig forbids that field with semantic_v8_policy. A real TrainConfig built from the V8 production template succeeds, then the unchanged launch configuration guard refuses it. Replacing just that guard would be incomplete because downstream launch supply/budget gates are V6.",
    "4. **Default package/catalog/preset/CLI routes remain old.** Explicit V8 entry and training/export/serve paths exist, but default training/aggregate semantic/Natlang package entries, default semantic stream catalog, old common/effectful/seed planner, and private release packager/restorer still route through old wire.",
    "5. **The ordinary V8 qualifier still requires legacy clients.** An actual serialized source task with traceVersion8 fails before compilation because generation-worker eagerly imports effectful-admit. The installed V8 worker is a separate path; its absence proof does not qualify this ordinary worker.\n\n6. **One overlooked dynamic dependency is now repaired.** Real ordinary V8 shard export previously called the legacy census dispatcher, importing old contracts even though the V8 entrypoint import gate passed. Published consumer commit776519e routes coverage directly by actual schema. Three new real preparation/export/reload absence controls preserve exact shard/index/manifest bytes, selected bytes, public contexts and derived coverage. Source/tokenizer audit boundaries are explicitly injected; these controls do not claim production admission.", "",
    "## Evidence and limits", "",
    "The JSON companion records source hashes, current inventory heads, every package entry, all identified route groups, concrete replacement paths, existing executable tests/commands, and missing parity. Tests referenced in the route table were inspected; their presence is not a fresh pass. Root owns final paired qualification and published commit remapping.", "",
    "Fresh before/after export evidence: the targeted pre-fix failure is retained (1failure,1.51s); the three ordinary/protocol/callback absence controls pass (3tests,20.46s). A broader existing-data selection yields8pass/3fail in21.32s; all three failures are absent local torch, retained unchanged. Ruff check and formatting passed for the two modified files. No optimizer/model execution occurred in this inventory.", "",
    "The producer entry probe blocks exactly the existing18-client installed qualification list. Root, explicit semantic/v8, Node capabilities and storage imports work; training, aggregate semantic and Natlang selected imports fail on actual legacy dependencies. The actual ordinary qualifier worker source task also refuses on effectful-admit before V8 compilation. This establishes route dependency, not source admission or model parity. Consumer dispatch and launch probes execute unchanged function bodies while omitting unrelated inference decorators/model imports; they establish route/guard behavior, not successful actual orchestration or launch asset validation.", "",
    "## Route map", "",
    "| ID | Repository / surface | Current status | Existing V8 replacement and evidence | Remaining parity |",
    "| --- | --- | --- | --- | --- |",
]
for item in rows:
    quote = lambda text: text.replace("|", "\\|").replace("\n", " ")
    evidence = ", ".join("`" + path + "`" for path in item["executableEvidence"]["paths"])
    lines.append("| " + " | ".join(map(quote, [item["id"], item["repository"] + " — " + item["surface"],
        item["status"] + ": " + item["currentBehavior"], item["v8Replacement"]["description"] + " Evidence: " + evidence,
        " ".join(item["remainingParityOrEvidence"])])) + " |")
lines += ["", "## Smallest hardest implementation to do next", "",
    inventory["nextHardestIncrement"]["deliverable"], "",
    "Start with a neutral typed child binding, not a codec adapter. Bind exact program source, invocation/input, grants, realm/completion policy and the acknowledged V8 public cut. Preserve original coordinator selections and child candidate acknowledgements separately. Port old controlled create/join/progress/complete/cancel and checkpoint/restore controls, including a child reserved before first sample, a parent waiting on completion, malformed actual model output, cancellation races and exactly-once completion delivery. Then retain source-qualified V8 lifecycle rows and derive the required curriculum labels from those rows.", "",
    inventory["nextHardestIncrement"]["independentFollowup"], "",
    "## What should remain explicit", "",
    "Owned execution/archive APIs, observational trace formats and pure reference tools are not selected-wire compatibility shims. Generic Megatoken prepare/serve and unrelated dataset/model version names are not V6 semantic routes. Existing V8 callbacks, closed-session tombstones, independent native replay, ordinary optimizer/resume/export, service deduplication and owner/terminal fencing are real scoped implementations; none proves complete coordinator/Natlang/resource/default-release parity. Complete old release archives and active current V8 release archives are different verification obligations.", "",
    "No default routing, stage requirement, schema or model code was changed for this inventory. The only authorized source repair is the narrow ordinary V8 coverage import fix, separately committed and sent for publication. The unimplemented routes remain explicit blockers.", "",
]
(OUT / "route-inventory.md").write_text("\n".join(lines))
print(json.dumps({"rows": len(rows), "entries": len(entries), "files": len(files), "missingReferences": missing}, indent=2))
